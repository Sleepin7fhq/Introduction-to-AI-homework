//! 学习模式：一段可自定义时长的专注时段，期间如果有浏览器窗口被打开就提醒。
//!
//! 检测方式：学习时段开始时记录当前已经存在的浏览器窗口（进程号 + 窗口句柄），
//! 之后每秒枚举一次顶层可见窗口，出现「基线里没有」的浏览器窗口即视为新打开浏览器。
//! 这样既不会因为本来就开着的浏览器误报，也能抓住「浏览器已经在运行、又新开一个窗口」。
//!
//! 判定逻辑（名单、新窗口比较、倒计时格式化）都是纯函数，可以在任意平台上
//! 单元测试；只有窗口枚举和弹窗是 Windows 专用的。

#[cfg(windows)]
use windows_sys::Win32::{
    Foundation::{CloseHandle, BOOL, HWND, LPARAM},
    System::Threading::{
        OpenProcess, QueryFullProcessImageNameW, PROCESS_QUERY_LIMITED_INFORMATION,
    },
    UI::WindowsAndMessaging::{
        EnumWindows, GetWindowTextLengthW, GetWindowThreadProcessId, IsWindowVisible,
    },
};

/// 自定义时长的允许范围见 `config::STUDY_MIN_MINUTES` / `STUDY_MAX_MINUTES`；
/// 面板上的快捷档位见 `config::STUDY_PRESETS`。
/// 连续提醒之间的最短间隔（秒），避免一次开一堆窗口时弹窗刷屏。
pub const REMIND_COOLDOWN: f64 = 45.;

/// 常见浏览器的可执行文件名（小写、不含路径）。
/// 桌面版浏览器基本都在这里；没有列到的名字可以在下面 `is_browser` 里补。
const BROWSERS: &[&str] = &[
    "chrome.exe",
    "chromium.exe",
    "msedge.exe",
    "msedgewebview2.exe",
    "firefox.exe",
    "brave.exe",
    "opera.exe",
    "opera_gx.exe",
    "vivaldi.exe",
    "iexplore.exe",
    "arc.exe",
    "thorium.exe",
    "yandex.exe",
    "waterfox.exe",
    "librewolf.exe",
    "floorp.exe",
    "zen.exe",
    "palemoon.exe",
    "seamonkey.exe",
    "safari.exe",
    "k-meleon.exe",
    // 国内常见外壳浏览器
    "360se.exe",
    "360chrome.exe",
    "360se6.exe",
    "qqbrowser.exe",
    "sogouexplorer.exe",
    "liebao.exe",
    "2345explorer.exe",
    "maxthon.exe",
    "ucbrowser.exe",
    "theworld.exe",
    "baidubrowser.exe",
];

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct BrowserWindow {
    pub pid: u32,
    pub hwnd: usize,
    /// 可执行文件名，已转成小写（例如 `chrome.exe`）。
    pub exe: String,
}

/// 取路径中的文件名部分（大小写不敏感地区分目录分隔符）。
fn file_name(path: &str) -> &str {
    path.rsplit(['\\', '/']).next().unwrap_or(path)
}

/// 这个可执行文件名是不是浏览器。
pub fn is_browser(path: &str) -> bool {
    let name = file_name(path).to_ascii_lowercase();
    BROWSERS.contains(&name.as_str())
}

/// 给用户看的浏览器名字。
pub fn display_name(exe: &str) -> String {
    let stem = file_name(exe)
        .to_ascii_lowercase()
        .trim_end_matches(".exe")
        .to_string();
    match stem.as_str() {
        "chrome" => "Chrome".into(),
        "chromium" => "Chromium".into(),
        "msedge" => "Edge".into(),
        "msedgewebview2" => "Edge".into(),
        "firefox" => "Firefox".into(),
        "brave" => "Brave".into(),
        "opera" | "opera_gx" => "Opera".into(),
        "vivaldi" => "Vivaldi".into(),
        "iexplore" => "Internet Explorer".into(),
        "360se" | "360se6" => "360 浏览器".into(),
        "360chrome" => "360 极速浏览器".into(),
        "qqbrowser" => "QQ 浏览器".into(),
        "sogouexplorer" => "搜狗浏览器".into(),
        "liebao" => "猎豹浏览器".into(),
        "baidubrowser" => "百度浏览器".into(),
        "" => "浏览器".into(),
        other => {
            let mut chars = other.chars();
            match chars.next() {
                Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
                None => "浏览器".into(),
            }
        }
    }
}

/// 基线之外的全部浏览器窗口。
pub fn fresh_all<'a>(baseline: &[BrowserWindow], current: &'a [BrowserWindow]) -> Vec<&'a BrowserWindow> {
    current
        .iter()
        .filter(|w| !baseline.iter().any(|b| b.hwnd == w.hwnd && b.pid == w.pid))
        .collect()
}

/// 把剩余秒数写成中文倒计时文案。
pub fn format_remaining(seconds: i64) -> String {
    let seconds = seconds.max(0);
    let hours = seconds / 3600;
    let minutes = seconds % 3600 / 60;
    let rest = seconds % 60;
    if hours > 0 {
        format!("{hours} 小时 {minutes:02} 分")
    } else if minutes > 0 {
        format!("{minutes} 分 {rest:02} 秒")
    } else {
        format!("{rest} 秒")
    }
}

/// 缩短版：托盘菜单用。
pub fn format_short(seconds: i64) -> String {
    let minutes = (seconds.max(0) + 59) / 60;
    if minutes >= 60 {
        format!("{} 小时 {} 分", minutes / 60, minutes % 60)
    } else {
        format!("{minutes} 分")
    }
}

/// 提醒正文。
pub fn reminder_text(name: &str, seconds: i64) -> String {
    format!(
        "检测到打开了 {name}。\n\n现在是学习时段，还剩 {}。\n先把这一页关掉，专心学完再说吧！",
        format_remaining(seconds)
    )
}

/// Unix 秒（带小数），跨进程/跨重启都可用，不受开机时长影响。
pub fn now_unix() -> f64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs_f64())
        .unwrap_or(0.)
}

/// 枚举当前所有「可见、有标题、进程名属于浏览器」的顶层窗口。
#[cfg(windows)]
pub fn browsers() -> Vec<BrowserWindow> {
    use std::collections::HashMap;

    unsafe extern "system" fn collect(hwnd: HWND, param: LPARAM) -> BOOL {
        if IsWindowVisible(hwnd) == 0 || GetWindowTextLengthW(hwnd) <= 0 {
            return 1;
        }
        let mut pid = 0u32;
        GetWindowThreadProcessId(hwnd, &mut pid);
        if pid != 0 {
            (*(param as *mut Vec<(u32, usize)>)).push((pid, hwnd as usize));
        }
        1
    }

    let mut raw: Vec<(u32, usize)> = Vec::new();
    unsafe {
        EnumWindows(Some(collect), &mut raw as *mut _ as LPARAM);
    }
    let mine = std::process::id();
    let mut names: HashMap<u32, Option<String>> = HashMap::new();
    let mut windows = Vec::new();
    for (pid, hwnd) in raw {
        if pid == mine {
            continue;
        }
        let name = names.entry(pid).or_insert_with(|| unsafe { process_name(pid) });
        if let Some(exe) = name {
            if is_browser(exe) {
                windows.push(BrowserWindow {
                    pid,
                    hwnd,
                    exe: file_name(exe).to_ascii_lowercase(),
                });
            }
        }
    }
    windows
}

/// 读取进程的可执行文件完整路径。
#[cfg(windows)]
unsafe fn process_name(pid: u32) -> Option<String> {
    let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
    if handle.is_null() {
        return None;
    }
    let mut buffer = [0u16; 1024];
    let mut size = buffer.len() as u32;
    let ok = QueryFullProcessImageNameW(handle, 0, buffer.as_mut_ptr(), &mut size);
    CloseHandle(handle);
    if ok == 0 || size == 0 {
        return None;
    }
    Some(String::from_utf16_lossy(&buffer[..size as usize]))
}

/// 非 Windows 平台（macOS 构建共用 `config`，但不含本模块）留一个空实现，
/// 让 `cfg` 之外的代码在编译时不需要分支。
#[cfg(not(windows))]
pub fn browsers() -> Vec<BrowserWindow> {
    Vec::new()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn win(pid: u32, hwnd: usize, exe: &str) -> BrowserWindow {
        BrowserWindow {
            pid,
            hwnd,
            exe: exe.into(),
        }
    }

    #[test]
    fn recognizes_major_browsers_case_and_path_insensitively() {
        for path in [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"D:\Edge\MSEDGE.EXE",
            "/Applications/Firefox.app/Contents/MacOS/firefox.exe",
            "360chrome.exe",
        ] {
            assert!(is_browser(path), "{path}");
        }
        for path in [
            r"C:\Windows\explorer.exe",
            "notepad.exe",
            "chrome.txt",
            r"C:\Tools\my-chrome.exe",
            "",
        ] {
            assert!(!is_browser(path), "{path}");
        }
    }

    #[test]
    fn detects_only_windows_beyond_the_baseline() {
        let baseline = vec![win(10, 100, "chrome.exe"), win(11, 101, "msedge.exe")];
        // 同一批窗口即使标题变了也不算新打开。
        let same = vec![win(10, 100, "chrome.exe"), win(11, 101, "msedge.exe")];
        assert!(fresh_all(&baseline, &same).is_empty());
        // 同一个进程新开窗口：句柄不同，算新打开。
        let grown = vec![
            win(10, 100, "chrome.exe"),
            win(10, 102, "chrome.exe"),
            win(11, 101, "msedge.exe"),
        ];
        let found = fresh_all(&baseline, &grown);
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].hwnd, 102);
        // 全新进程。
        let launched = vec![win(12, 200, "firefox.exe")];
        let found = fresh_all(&baseline, &launched);
        assert_eq!(found[0].exe, "firefox.exe");
    }

    #[test]
    fn empty_baseline_reports_everything() {
        let launched = vec![win(1, 2, "chrome.exe")];
        assert_eq!(fresh_all(&[], &launched)[0].pid, 1);
        assert!(fresh_all(&[], &[]).is_empty());
    }

    #[test]
    fn remaining_time_is_readable() {
        assert_eq!(format_remaining(0), "0 秒");
        assert_eq!(format_remaining(-5), "0 秒");
        assert_eq!(format_remaining(42), "42 秒");
        assert_eq!(format_remaining(65), "1 分 05 秒");
        assert_eq!(format_remaining(25 * 60), "25 分 00 秒");
        assert_eq!(format_remaining(3600), "1 小时 00 分");
        assert_eq!(format_remaining(3600 + 5 * 60 + 7), "1 小时 05 分");
        assert_eq!(format_short(30), "1 分");
        assert_eq!(format_short(45 * 60), "45 分");
        assert_eq!(format_short(90 * 60), "1 小时 30 分");
    }

    #[test]
    fn reminder_text_mentions_browser_and_countdown() {
        let text = reminder_text("Chrome", 25 * 60);
        assert!(text.contains("Chrome"));
        assert!(text.contains("25 分"));
        assert_eq!(display_name("msedge.exe"), "Edge");
        assert_eq!(display_name("weird-browser.exe"), "Weird-browser");
    }
}
