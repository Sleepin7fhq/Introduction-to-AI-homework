#ifndef PET_CORE_H
#define PET_CORE_H
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
typedef struct PetCore PetCore;
PetCore *pet_create(const char *dir);
void pet_destroy(PetCore *core);
const char *pet_settings(PetCore *core);
const char *pet_error(PetCore *core);
bool pet_apply(PetCore *core, const char *json);
bool pet_preview(PetCore *core, const char *json);
bool pet_import(PetCore *core, const char *path);
bool pet_import_profile(PetCore *core, const char *skin_path, const char *cape_path, const char *name, const char *model);
bool pet_reset(PetCore *core);
bool pet_restore_skin(PetCore *core);
const char *pet_cape_catalog(PetCore *core);
const uint8_t *pet_cape_png(uint32_t index, size_t *length);
bool pet_select_cape(PetCore *core, const char *id);
void pet_key(PetCore *core, uint32_t key, bool down, float now);
void pet_clear_keys(PetCore *core);
void pet_click(PetCore *core, float now);
const uint8_t *pet_render(PetCore *core, float x, float y, float width, float height, bool shift, float now, float dt);
bool pet_hit(PetCore *core, float x, float y);
/// x/y: screen points. Returns the PAT meow to play (0 or 1), or -1 for none.
int32_t pet_mouse(PetCore *core, uint32_t button, bool over, float x, float y, float now);
/// Long-press pat; returns 1 while the window must not be dragged yet.
uint32_t pet_hold_update(PetCore *core, bool down, float x, float y, float tolerance, float now);
void pet_hold_cancel(PetCore *core, float now);
void pet_feed(PetCore *core, float now);
void pet_music(PetCore *core, bool playing);
/// kind: 0 wave, 1 bounce, 2 shy, 3 clap. Returns false for an unknown kind.
bool pet_gesture(PetCore *core, uint32_t kind, float now);
bool pet_needs_frames(PetCore *core, float now);
/// 0 idle, 1 breathing only, 2 interactive animation. Read-only; time is seconds since start.
uint32_t pet_frame_demand(PetCore *core, float now);
/// Bounds-checked resize; invalidates pet_pixels pointer only when dimensions change.
bool pet_resize(PetCore *core, uint32_t width, uint32_t height);
const uint8_t *pet_pixels(PetCore *core);
bool pet_set_glyphs(const uint8_t *bytes, size_t length);
#endif
