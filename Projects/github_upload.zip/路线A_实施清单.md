# 路线 A 实施清单：music21 + 规则/DP + fluidsynth

> 结论：不用写乐理库，也不用写 MIDI 解析器。要写的是**决策层**（选哪些和弦、怎么排声部、用什么织体）
> 和**胶水层**（把 music21 的对象转成自己的数据结构，再把结果写回去）。核心约 900 行。

## 1. 先分清：哪些不用自己写

| 能力 | 交给谁 | 说明 |
| --- | --- | --- |
| 解析 MIDI / MusicXML / ABC | `music21.converter.parse` | 多轨、速度、拍号一起读进来 |
| 调性分析 | `score.analyze('key')` | Krumhansl 轮廓，附带 `alternateInterpretations` |
| 拍号、小节线 | `meter.TimeSignature`、`score.measureOffsetMap()` | 弱起用 `score.pickup` 判断 |
| 和弦构成、罗马数字 | `chord.Chord`、`roman.RomanNumeral` | `RomanNumeral('V7', key).pitches` 直接给音 |
| 平行五/八度检测 | `analysis.voiceLeading.VoiceLeadingQuartet` | 验收时用，不必自己写规则 |
| MIDI 导出 | `stream.write('midi', fp=...)` | 多轨、通道、program 都能设 |
| MIDI → WAV | `fluidsynth` 命令行 + SoundFont | 不要自己写合成器 |

## 2. 要写的六个模块

| 文件 | 职责 | 关键函数 | 预计行数 |
| --- | --- | --- | --- |
| `io.py` | 读入、量化、提取单声部旋律、统一数据结构 | `load_melody(path) -> Melody` | 80 |
| `analysis.py` | 调性、拍号、小节、乐句切分 | `detect_key()`、`phrase_ends()` | 80 |
| `harmony.py` | 候选和弦、槽内打分、功能进行、Viterbi | `harmonize(melody, key) -> list[ChordSlot]` | 280 |
| `voicing.py` | 声部连接、低音、音区控制 | `voice(chord, prev) -> tuple[int, ...]` | 120 |
| `texture.py` | 柱式/阿尔贝蒂/分解/圆舞曲/反拍/长音 | `render_pattern(style, slot) -> list[NoteEvent]` | 160 |
| `render.py` | 写 MIDI、调 fluidsynth、错误处理 | `export_midi()`、`render_wav()` | 70 |
| `cli.py` | 参数、日志、和弦谱输出 | `main()` | 80 |
| `tests/` | 每模块的硬性检查 | — | 150 |

合计约 900–1000 行，其中真正的“音乐决策”约 600 行。

## 3. 统一数据结构（先定这个，后面都围绕它写）

```python
from dataclasses import dataclass

@dataclass
class NoteEvent:
    pitch: int          # MIDI 音高
    start: float        # 拍（四分音符 = 1）
    dur: float
    velocity: int = 90

@dataclass
class Melody:
    notes: list[NoteEvent]
    bpm: float
    beats_per_bar: float
    time_sig: tuple[int, int]
    pickup: bool = False

@dataclass
class ChordSlot:
    bar: int
    start: float
    end: float
    chord: object       # music21.harmony.ChordSymbol 或自定义
```

## 4. 关键接口

```python
def load_melody(path: str, track: int | None = None) -> Melody: ...
def detect_key(melody: Melody) -> tuple[str, float]: ...          # 如 ("C", 0.87)
def phrase_ends(melody: Melody, phrase_bars: int = 4) -> set[int]: ...
def harmonize(melody, key, chords_per_bar: int = 1) -> list[ChordSlot]: ...
def voice(chord, prev: tuple[int, ...] | None, lo=52, hi=79) -> tuple[int, ...]: ...
def render_pattern(style: str, slot: ChordSlot, voicing, bass,
                   beats_per_bar: float, velocity: int) -> list[NoteEvent]: ...
def export_midi(melody, chords, bass, path: str, key: str) -> None: ...
def render_wav(midi_path: str, sf2_path: str, wav_path: str) -> None: ...
```

## 5. 和声 DP 的核心（伪代码）

```python
vocab = diatonic_triads(key) + [V7(key)] + secondary_dominants(key)

def emission(slot, chord):                 # 槽内契合度
    s = 0
    for note in notes_in(slot):
        w = metric_weight(note.start)      # 强拍 1.0，弱拍 0.4
        s += (1.0 if note.pc in chord.pcs else -0.5) * w
    return s / total_weight

def transition(prev, cur, phrase_end):     # 槽间进行
    s = 0
    if cur.root == (prev.root + 5) % 12: s += 0.35   # 上行四度
    s += {"T->S": 0.3, "S->D": 0.45, "D->T": 0.55}.get((prev.func, cur.func), 0)
    if phrase_end and cur.degree == 1: s += 2.0      # 终止式
    if phrase_end and last_note_not_in(cur): s -= 1.0
    return s

# Viterbi：best[i][j] = emission(i,j) + max_k(best[i-1][k] + transition(k,j))
```

规则之外的“品味”，全部体现在这几个权重上。**建议先把权重写成配置表**，否则调参会调到崩溃。

## 6. 生成的三个声部

1. **旋律轨**：原样保留，velocity 90–100。
2. **和弦轨**：每小节 1–4 个和弦，3–4 个音，音区在旋律下方，声部尽量少动。
3. **低音轨**：根音或五音，音区 36–52，优先级进。

织体先把 `block` 和 `alberti` 做对，再扩展到其他四种；每加一种，都要在 10 首测试集上回归。

## 7. MIDI → WAV

```bash
fluidsynth -ni -g 0.8 -r 44100 soundfont.sf2 in.mid -F out.wav
```

- `sf2` 用绝对路径，否则在子进程里找不到。
- 没装 fluidsynth 时，先只导出 MIDI（DAW 里也能听），不要卡在渲染上。
- 想更好听，换 `FluidR3_GM.sf2`，或者在 DAW 里换钢琴音源。

## 8. 最容易翻车的六件事

1. **量化**：MIDI 时值常常是 0.4999，先 `score.quantize([4, 3])` 再转拍。
2. **弱起**：第一小节不满，终止式会整体错位；用 `score.pickup` 或小节长度判断。
3. **多轨**：流行 MIDI 常把旋律放在第 2、3 轨，按音区中位数或轨道名选，不要默认第 1 轨。
4. **调性误判**：关系大小调音集相同，短旋律必错；把 `alternateInterpretations` 一起看，或用终止音兜底。
5. **和弦外音**：强拍的经过音如果按弱拍权重算，会选出奇怪的和弦；权重表要单独调。
6. **music21 的 offset 单位是拍**，不是秒；tempo 变化时不要混用。

## 9. 验收（每模块一条硬指标）

| 模块 | 检查 |
| --- | --- |
| io | 10 首 MIDI round-trip，音高/时值误差 < 1 tick |
| analysis | 调性 8/10 正确；乐句边界与人工标注差 ≤ 1 小节 |
| harmony | 末尾落在主和弦；强拍冲突率 < 20% |
| voicing | 音域 48–79；相邻和弦声部平均移动 < 5 半音 |
| texture | 每小节音符数在预期范围；无重叠同音 |
| render | WAV 时长与谱面一致；峰值 < 0 dBFS |

## 10. 排期（AI 代写、人类验收）

| 天 | 内容 |
| --- | --- |
| D1 | `io.py` + `analysis.py` + 单和弦跑通 |
| D2 | `harmony.py` 的候选与 DP |
| D3 | `voicing.py` + `texture.py` 两种织体 |
| D4 | `render.py` + CLI + 10 首回归 |
| D5 | 调参、补三种织体、写测试 |

## 11. 可以直接抄的部分

本仓库的 `melody_accompanist/harmonize.py` 和 `arrange.py` 已经把打分、Viterbi、声部连接、六种织体写完了，
只是输入输出换成了自写的数据结构。路线 A 可以把它当作“参考实现”，把 IO 和乐理换成 music21 即可，
省掉大约一半的调试时间。
