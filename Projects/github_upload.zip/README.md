# 把旋律变成乐队

一个可解释的自动配伴奏原型：输入单声部旋律（MIDI / MusicXML），输出多轨伴奏 MIDI、试听 WAV 和和弦谱。

不是端到端音频生成，而是“符号化编曲”：

- 调性/乐句/旋律/低音骨架分析
- 候选和弦 + Viterbi 搜索
- 13 种织体、低音转位与经过音
- 多层配器（音区/和弦音子集/节奏互补/乐器档案）
- CC7 声部平衡 + CC11 表情 + 混响
- tkinter 可视化界面，支持自动配置

## 目录

```text
route_a/          源代码（分析、和声、编配、渲染、界面）
tests/            单元测试、回归、基准脚本、11 首示例 MIDI
tools/bin/ir/     三个真实厅堂 IR（Voxengo 免费包，license.txt 随附）
run_cli.cmd       命令行启动
run_gui.cmd       图形界面启动
run_tests.cmd     单元测试
run_benchmark.cmd 巴赫众赞歌 / ASAP 基准
使用说明.md        完整参数与常见问题
创意报告*.docx     课程创意报告
*_创意作品汇报.pptx 答辩 PPT
```

## 快速开始（源码方式）

需要：

- Python 3.12
- FluidSynth 2.x
- 一个 GM SoundFont（推荐 FluidR3_GM 或 MuseScore_General）

```powershell
python -m pip install -r requirements.txt
```

把 FluidSynth 和 SoundFont 放到：

```text
tools/bin/fluidsynth/.../fluidsynth.exe
tools/bin/soundfonts/fluid-soundfont-3.1/FluidR3_GM.sf2
```

或用环境变量指定：

```powershell
$env:FLUIDSYNTH="D:\FluidSynth\bin\fluidsynth.exe"
$env:SOUNDFONT="D:\SoundFonts\FluidR3_GM.sf2"
```

然后：

```powershell
python -m route_a.cli tests/data/02_ode_to_joy.mid --auto
```

或双击 `run_cli_source.cmd` / `run_gui_source.cmd`（需要本机 Python 和依赖）。
`run_cli.cmd`、`run_gui.cmd` 是发布包专用（使用包内 `runtime\`），源码目录请用 `*_source.cmd`。

## 关于发布包

完整版（含 Python 运行时、FluidSynth、三套音色库，约 478MB）**不放在 Git 仓库里**，
请作为 GitHub Release 附件或网盘交付。仓库只保留源码、测试、文档和小体积 IR。

## 许可证

- 代码：课程作业用途
- 真实 IR：Voxengo 免费包，license.txt 允许商用/再分发
- 示例 MIDI：项目自制
- ASAP 数据集：CC BY-NC-SA 4.0，仅用于本地评估，未包含在本仓库
