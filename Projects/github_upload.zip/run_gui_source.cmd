@echo off
setlocal
cd /d "%~dp0"
python -m route_a.gui %*
if errorlevel 1 pause
