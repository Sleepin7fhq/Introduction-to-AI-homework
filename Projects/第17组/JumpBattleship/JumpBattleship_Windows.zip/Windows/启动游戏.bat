@echo off
chcp 65001 >nul
title 跳跃战舰
setlocal
cd /d "%~dp0"

set "EXE=%~dp0跳跃战舰.exe"

if not exist "%EXE%" goto noexe

echo.
echo   正在打开《跳跃战舰》……
echo   窗口大概 3 秒后出现，这个黑窗口会自动关掉，不用管它。
echo.
start "" "%EXE%"
exit /b 0

:noexe
echo.
echo   [ 没找到游戏程序 ]
echo.
echo   说明这个游戏还没打包过。
echo   请先双击同一个文件夹里的「重新打包.bat」，
echo   等它跑完（大约 1~3 分钟）再回来双击本文件。
echo.
pause
exit /b 1
